import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});
app.use(express.json({ limit: '50mb' }));

app.post('/api/save-session', (req, res) => {
  const { filename, transcript, audio } = req.body;
  const saveDir = path.join(__dirname, 'sessions');

  if (!fs.existsSync(saveDir)) {
    fs.mkdirSync(saveDir, { recursive: true });
  }

  // Save transcript
  fs.writeFileSync(path.join(saveDir, `${filename}.txt`), transcript);

  // Save audio
  if (audio) {
    const audioBuffer = Buffer.from(audio, 'base64');
    fs.writeFileSync(path.join(saveDir, `${filename}.webm`), audioBuffer);
  }

  res.json({ success: true, path: saveDir });
});

app.listen(3001, () => console.log('Save server running on :3001'));
